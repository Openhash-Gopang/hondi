﻿import re, shutil
from pathlib import Path

base = Path(r'C:\Users\주피터\Downloads\case_summary\scores')
threshold = 7.0

def get_score(filepath):
    text = filepath.read_text(encoding='utf-8', errors='replace')
    body = '\n'.join(l for l in text.splitlines() if not l.startswith('#'))
    body_plain = re.sub(r'\*\*', '', body)
    na_patterns = [
        r'종합\s*점수\s*[:]\s*N/A',
        r'최종\s*[:]\s*N/A',
        r'종합\s*점수\s*[:]\s*\[면책\]',
        r'최종\s*점수\s*[:]\s*\[면책\]',
        r'면책\s*사유\s*[:]\s*(?!없음|해당\s*없음|\(해당\s*시\)|N/A)\S',
    ]
    for p in na_patterns:
        if re.search(p, body_plain):
            return None
    score_patterns = [
        r'최종\s*점수\s*[:]\s*([0-9.]+)',
        r'최종\s*[:]\s*([0-9.]+)\s*점',
        r'종합\s*점수\s*[:]\s*([0-9.]+)',
        r'([0-9]+(?:\.[0-9]+)?)\s*/\s*10\s*점',
        r'총점\s*[:]\s*([0-9.]+)',
    ]
    for p in score_patterns:
        m = re.search(p, body_plain)
        if m:
            try:
                return float(m.group(1))
            except:
                continue
    return None

for rnd in ['6회차', '7회차']:
    pass_dir = base / rnd
    fail_dir = base / (rnd + ' 재평가 대상')
    fail_dir.mkdir(exist_ok=True)
    moved = 0
    for f in sorted(pass_dir.glob('*_score.txt')):
        score = get_score(f)
        is_fail = (score is None) or (score < threshold)
        if is_fail:
            shutil.move(str(f), str(fail_dir / f.name))
            moved += 1
            label = str(score) if score is not None else 'N/A'
            print(rnd + ' 재평가: ' + f.name + ' - ' + label)
    total = len(list(pass_dir.glob('*_score.txt')))
    print(rnd + ': 합격 ' + str(total) + '건 / 재평가 대상 ' + str(moved) + '건')
    print()
