﻿import re
from pathlib import Path
from statistics import mean

SCORES_DIR = Path(r'C:\Users\주피터\Downloads\case_summary\scores')

def extract_scores(folder: Path) -> list:
    scores = []
    for f in folder.glob('*_score.txt'):
        txt = f.read_text(encoding='utf-8', errors='replace')
        # 여러 패턴으로 종합 점수 추출
        for pattern in [
            r'종합\s*점수[^\d]*([\d.]+)\s*/\s*10',
            r'최종\s*점수[^\d]*([\d.]+)\s*/\s*10',
            r'총점[^\d]*([\d.]+)\s*/\s*10',
            r'점수[^\d]*([\d.]+)\s*/\s*10',
        ]:
            m = re.search(pattern, txt)
            if m:
                val = float(m.group(1))
                if 0 <= val <= 10:
                    scores.append(val)
                break
    return scores

# 회차별 점수 수집 (정규 + 재평가 합산)
results = {}

for d in SCORES_DIR.iterdir():
    if not d.is_dir():
        continue
    # 정규 회차 폴더
    m = re.match(r'^(\d+)회차$', d.name)
    if m:
        rno = int(m.group(1))
        if rno not in results:
            results[rno] = []
        results[rno].extend(extract_scores(d))
        continue
    # 재평가 대상 폴더
    m2 = re.match(r'^(\d+)회차\s*재평가\s*대상$', d.name)
    if m2:
        rno = int(m2.group(1))
        if rno not in results:
            results[rno] = []
        results[rno].extend(extract_scores(d))

# 정렬 출력
print('=' * 72)
print(f'{"회차":>4}  {"건수":>4}  {"평균":>6}  {"최저":>6}  {"최고":>6}  트렌드')
print('=' * 72)

prev_avg = None
rows = []
for rno in sorted(results):
    sc = results[rno]
    if not sc:
        continue
    avg = round(mean(sc), 2)
    rows.append((rno, len(sc), avg, min(sc), max(sc)))

for i, (rno, cnt, avg, lo, hi) in enumerate(rows):
    if i == 0:
        trend = '  (기준)'
    else:
        diff = avg - rows[i-1][2]
        trend = f'{"▲" if diff>0 else "▼" if diff<0 else "─"} {abs(diff):.2f}'
    bar = '█' * int(avg)
    print(f'{rno:>4}회차  {cnt:>4}건  {avg:>6.2f}  {lo:>6.2f}  {hi:>6.2f}  {trend}  {bar}')

print('=' * 72)
avgs = [r[2] for r in rows]
print(f'전체 평균: {mean(avgs):.2f}/10')
print(f'최고 회차: {rows[avgs.index(max(avgs))][0]}회차 ({max(avgs):.2f}점)')
print(f'최저 회차: {rows[avgs.index(min(avgs))][0]}회차 ({min(avgs):.2f}점)')
print()
print('=== K-Law 갱신 시점과의 관계 ===')
print('v13.x → v14.0 전환: 약 10회차 전후')
print('v14.3 → v14.4 갱신: 18회차 2배치 (5.35점 트리거)')
print('v14.4 → v14.5~v14.9: 19~22회차 연속 갱신')
