﻿import re
import json
from pathlib import Path
from statistics import mean

SCORES_DIR = Path(r'C:\Users\주피터\Downloads\case_summary\scores')

# 회차별 점수 수집
results = {}

for d in SCORES_DIR.iterdir():
    if not d.is_dir():
        continue
    # 재평가 대상 폴더 제외, 순수 회차 폴더만
    name = d.name
    m = re.match(r'^(\d+)회차$', name)
    if not m:
        continue
    round_no = int(m.group(1))
    
    scores = []
    for f in d.glob('*_score.txt'):
        txt = f.read_text(encoding='utf-8', errors='replace')
        # 종합 점수 추출
        sm = re.search(r'종합\s*점수[^\d]*([\d.]+)\s*/\s*10', txt)
        if not sm:
            sm = re.search(r'최종\s*점수[^\d]*([\d.]+)\s*/\s*10', txt)
        if not sm:
            sm = re.search(r'점수[^\d]*([\d.]+)\s*/\s*10', txt)
        if sm:
            val = float(sm.group(1))
            if 0 <= val <= 10:
                scores.append(val)
    
    if scores:
        results[round_no] = {
            'count': len(scores),
            'avg': round(mean(scores), 2),
            'min': round(min(scores), 2),
            'max': round(max(scores), 2),
        }

# 정렬 출력
print('=' * 65)
print(f'{"회차":>4}  {"건수":>4}  {"평균":>6}  {"최저":>6}  {"최고":>6}  트렌드')
print('=' * 65)

prev_avg = None
for rno in sorted(results):
    r = results[rno]
    avg = r['avg']
    if prev_avg is not None:
        diff = avg - prev_avg
        trend = f'{"▲" if diff > 0 else "▼" if diff < 0 else "─"} {abs(diff):.2f}'
    else:
        trend = '  (기준)'
    print(f'{rno:>4}회차  {r["count"]:>4}건  {avg:>6.2f}  {r["min"]:>6.2f}  {r["max"]:>6.2f}  {trend}')
    prev_avg = avg

print('=' * 65)
avgs = [results[r]['avg'] for r in sorted(results)]
if avgs:
    print(f'전체 평균: {mean(avgs):.2f}/10')
    print(f'최고 회차: {sorted(results, key=lambda r: results[r]["avg"])[-1]}회차 ({max(avgs):.2f}점)')
    print(f'최저 회차: {sorted(results, key=lambda r: results[r]["avg"])[0]}회차 ({min(avgs):.2f}점)')
