﻿from pathlib import Path
import re

BASE_DIR = Path(r'C:\Users\주피터\Downloads\case_summary')
SCORES_DIR = BASE_DIR / 'scores'

# 재평가 대상 폴더 목록
fail_dirs = sorted([d for d in SCORES_DIR.iterdir() 
                    if d.is_dir() and '재평가' in d.name])

print('=== 재평가 대상 폴더 ===')
for d in fail_dirs:
    files = list(d.glob('*_score.txt'))
    print(f'  {d.name}: {len(files)}건')
    for f in sorted(files)[:3]:
        m = re.search(r'(\d{6})', f.name)
        print(f'    {f.name}')
    if len(files) > 3:
        print(f'    ... 외 {len(files)-3}건')

print()

# 전체 재평가 대상 사건번호 수집
all_fail_ids = set()
for d in fail_dirs:
    for f in d.glob('*_score.txt'):
        m = re.search(r'(\d{6})', f.name)
        if m:
            all_fail_ids.add(m.group(1))

print(f'재평가 대상 사건번호 총 {len(all_fail_ids)}건:')
for cid in sorted(all_fail_ids):
    print(f'  {cid}')
