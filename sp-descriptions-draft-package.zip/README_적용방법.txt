SP 시민용 설명 초안 — 배포 패키지
================================
기준 커밋: 6a8fe6c (Openhash-Gopang/hondi, main) — 2026-09-09 확인

포함 파일
---------
1) sp-descriptions-draft.json
   - repo 루트의 data/ 폴더에 넣는 파일. SP 원문(.md)은 건드리지 않음.
   - 기관 998 + 페르소나 731 = 1,729건, 전부 draft_status 명시.

2) 0001-k-government-draft-badge.patch
   - pages/k-government.html 패치. K-정부 카탈로그(701개 기관) 카드에
     "초안" 배지 추가 (data/sp-descriptions-draft.json을 fetch해서 표시).

3) 0002-expert-personas-draft-badge.patch
   - pages/expert-personas.html 패치. 전문가 페르소나 카탈로그(505명)
     카드에 동일한 "초안" 배지 추가.

적용 순서 (PowerShell, Windows)
-------------------------------
# 0) 압축 파일은 보통 C:\Users\주피터\Downloads\ 로 저장되므로,
#    먼저 repo 폴더로 복사해 들어간다.
cd C:\Users\주피터\Downloads\hondi
Copy-Item C:\Users\주피터\Downloads\sp-descriptions-draft-package.zip .
Expand-Archive -Path .\sp-descriptions-draft-package.zip -DestinationPath .\_incoming -Force

# 1) 최신 main과 동기화 (다른 세션의 커밋을 덮어쓰지 않도록 항상 먼저 pull)
git checkout main
git pull origin main

# 2) 데이터 파일 배치
New-Item -ItemType Directory -Force -Path .\data | Out-Null
Copy-Item .\_incoming\sp-descriptions-draft.json .\data\sp-descriptions-draft.json -Force

# 3) 코드 패치 적용 (순서대로)
git am .\_incoming\0001-k-government-draft-badge.patch
git am .\_incoming\0002-expert-personas-draft-badge.patch

# 4) data/ 폴더는 git am이 다루지 않으므로 별도로 커밋
git add data\sp-descriptions-draft.json
git commit -m "data: SP 시민용 설명 초안(sp-descriptions-draft.json) 추가 — 998개 기관 + 731개 페르소나, 전부 draft_status 명시"

# 5) 반영
git push origin main

# 문제가 생기면 (git am 충돌 시)
git am --abort
# 위 패치는 .patch 파일이므로 git apply로도 시도 가능:
git apply --check .\_incoming\0001-k-government-draft-badge.patch
